#!/usr/bin/env python3
from pathlib import Path
import runpy
script=Path(__file__).resolve().parents[2]/'scripts/generate_phase4_figures.py'
ns=runpy.run_path(str(script))
ns['fig3']()
