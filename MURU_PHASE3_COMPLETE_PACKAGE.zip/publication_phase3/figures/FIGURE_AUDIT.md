# Figure audit

All five figures were regenerated from the committed analysis JSON and machine-readable tables using `python3.13 publication_phase3/analysis/generate_assets.py`. Values were not manually entered into the plotted series.

- figure_1_study_design: SVG, vector PDF, 400 dpi PNG; source: analysis/generate_assets.py; inspected for label fit, values, and annotations.
- figure_2_performance: SVG, vector PDF, 400 dpi PNG; source: analysis/generate_assets.py; inspected for label fit, values, and annotations.
- figure_3_external_errors: SVG, vector PDF, 400 dpi PNG; source: analysis/generate_assets.py; inspected for label fit, values, and annotations.
- figure_4_structural_novelty: SVG, vector PDF, 400 dpi PNG; source: analysis/generate_assets.py; inspected for label fit, values, and annotations.
- figure_5_energy_interface: SVG, vector PDF, 400 dpi PNG; source: analysis/generate_assets.py; inspected for label fit, values, and annotations.

Figure 2 shows the development point ratio without an interval because the historical max-T calculation was not recovered; its note identifies this provenance limit. Figure 4 labels Q1 as the most novel quartile and visibly shows the unfavorable 1.0083 ratio. Figures 3 and 5 annotate tail uncertainty and energy-interface uncertainty. All output formats were checked for file existence and nonzero size. Visual inspection identified and corrected an initial group-label reversal in Figure 2 and text overlap in Figures 1, 4 and 5.
